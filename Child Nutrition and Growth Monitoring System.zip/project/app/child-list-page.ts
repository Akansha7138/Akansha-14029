import { EventData, Page, NavigatedData } from '@nativescript/core';
import { ChildListViewModel } from './child-list-view-model';

export function navigatingTo(args: NavigatedData) {
    const page = <Page>args.object;
    page.bindingContext = new ChildListViewModel();
}