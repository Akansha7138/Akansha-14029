import { Observable } from '@nativescript/core';
import { ChildProfile } from './models/child';

export class ChildListViewModel extends Observable {
    private _children: ChildProfile[] = [];

    constructor() {
        super();
        // Initialize with sample data
        this.addSampleData();
    }

    get children(): ChildProfile[] {
        return this._children;
    }

    set children(value: ChildProfile[]) {
        if (this._children !== value) {
            this._children = value;
            this.notifyPropertyChange('children', value);
        }
    }

    onAddChild() {
        // TODO: Navigate to add child page
        console.log('Add child tapped');
    }

    onViewChild(args: any) {
        const child = args.object.bindingContext;
        // TODO: Navigate to child details page
        console.log('View child tapped:', child.name);
    }

    private addSampleData() {
        this.children = [
            new ChildProfile({
                id: '1',
                name: 'Emma Smith',
                birthDate: new Date(2020, 5, 15),
                gender: 'female',
                growth: [
                    {
                        date: new Date(),
                        height: 92,
                        weight: 13.5
                    }
                ]
            }),
            new ChildProfile({
                id: '2',
                name: 'Liam Johnson',
                birthDate: new Date(2021, 2, 10),
                gender: 'male',
                growth: [
                    {
                        date: new Date(),
                        height: 82,
                        weight: 11.2
                    }
                ]
            })
        ];
    }
}