import { Observable } from '@nativescript/core';

export interface Growth {
  date: Date;
  height: number;
  weight: number;
}

export interface Meal {
  date: Date;
  type: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  foods: string[];
  calories: number;
}

export interface Milestone {
  date: Date;
  title: string;
  description: string;
  achieved: boolean;
}

export class ChildProfile extends Observable {
  public id: string;
  public name: string;
  public birthDate: Date;
  public gender: 'male' | 'female';
  public growth: Growth[];
  public meals: Meal[];
  public milestones: Milestone[];

  constructor(data?: Partial<ChildProfile>) {
    super();
    this.growth = [];
    this.meals = [];
    this.milestones = [];
    Object.assign(this, data);
  }
}